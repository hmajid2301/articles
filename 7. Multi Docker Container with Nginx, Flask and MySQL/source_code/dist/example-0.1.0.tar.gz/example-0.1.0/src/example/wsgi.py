from .routes import app

application = app
